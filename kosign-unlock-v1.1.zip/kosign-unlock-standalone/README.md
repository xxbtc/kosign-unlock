# Kosign Unlock - Standalone Version

This is a completely self-contained version of Kosign Unlock that runs offline with **zero dependencies**.

## Requirements
- **No special requirements!** 
- Just a modern web browser (Chrome, Firefox, Safari, Edge)
- Optional: Python (for better experience with local server)

## Quick Start

### Option 1: Easy Start (Recommended)
**Windows:** Double-click `start.bat`  
**Mac/Linux:** Double-click `start.sh`

The script will:
- Try to start a local Python server (if available)
- Automatically open your browser
- Fall back to opening the file directly if Python isn't available

### Option 2: Direct File Access
Simply open `index.html` in your web browser by double-clicking it.

### Option 3: Manual Server (Best Experience)
If you have Python installed:
```bash
# Python 3
python3 -m http.server 8000

# Python 2  
python -m SimpleHTTPServer 8000
```
Then open: http://localhost:8000

## Features
✅ **Zero dependencies** - works completely standalone
✅ **Complete offline operation** - no internet required
✅ **All cryptographic functions work locally**
✅ **Secure QR code scanning**
✅ **Multiple vault format support** (V1 legacy + V2 single QR)
✅ **Camera switching** for mobile devices
✅ **Dark theme** optimized for security
✅ **Cross-platform** - works on Windows, Mac, Linux

## Security Notes
🔒 **Maximum Security Design:**
- This version runs completely offline for maximum security
- All vault decryption happens locally in your browser
- No data is sent to any external servers
- No external dependencies to worry about
- For best security, disconnect from internet before use

## Browser Compatibility
✅ Chrome 60+  
✅ Firefox 55+  
✅ Safari 12+  
✅ Edge 79+  

## Troubleshooting

**Camera not working?**
- Make sure you allow camera permissions when prompted
- Try the camera toggle button to switch between front/back cameras

**File access issues?**
- Some browsers restrict local file access for security
- Use the provided startup scripts for best experience
- Or serve the files through any web server

## Version: 0.1.0
## Created: 2025-06-28

---
**Kosign Unlock** - Secure, offline cryptocurrency vault unlocking tool  
GitHub: https://github.com/xxbtc/kosign-unlock

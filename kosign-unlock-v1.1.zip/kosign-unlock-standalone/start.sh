#!/bin/bash
echo ""
echo "================================"
echo "   Kosign Unlock - Starting..."
echo "================================"
echo ""

# Function to try starting Python server
start_python_server() {
    echo "🚀 Starting local server..."
    
    # Try Python 3 first
    if command -v python3 &> /dev/null; then
        echo "✅ Using Python 3"
        python3 -c "
import http.server
import socketserver
import webbrowser
import threading
import time

def open_browser():
    time.sleep(1.5)
    webbrowser.open('http://localhost:8000')

handler = http.server.SimpleHTTPRequestHandler
httpd = socketserver.TCPServer(('127.0.0.1', 8000), handler)
print('✅ Server running at: http://localhost:8000')
print('🔒 Kosign Unlock is now available offline!')
print('🛑 Press Ctrl+C to stop the server')
print('')

threading.Thread(target=open_browser).start()
httpd.serve_forever()
"
        return 0
    fi
    
    # Try Python 2 if Python 3 not available
    if command -v python &> /dev/null; then
        echo "✅ Using Python 2"
        python -c "
import SimpleHTTPServer
import SocketServer
import webbrowser
import threading
import time

def open_browser():
    time.sleep(1.5)
    webbrowser.open('http://localhost:8000')

handler = SimpleHTTPServer.SimpleHTTPRequestHandler
httpd = SocketServer.TCPServer(('127.0.0.1', 8000), handler)
print('✅ Server running at: http://localhost:8000')
print('🔒 Kosign Unlock is now available offline!')
print('🛑 Press Ctrl+C to stop the server')
print('')

threading.Thread(target=open_browser).start()
httpd.serve_forever()
"
        return 0
    fi
    
    return 1
}

# Try to start Python server
if ! start_python_server; then
    echo ""
    echo "❌ Python not found!"
    echo "Opening index.html directly in your default browser..."
    echo ""
    
    # Try different ways to open the file
    if command -v open &> /dev/null; then
        # macOS
        open index.html
    elif command -v xdg-open &> /dev/null; then
        # Linux
        xdg-open index.html
    else
        echo "Please open index.html manually in your browser"
    fi
    
    echo ""
    echo "💡 For best experience, install Python:"
    echo "   macOS: brew install python3"
    echo "   Ubuntu: sudo apt install python3"
    echo "   Or download from: https://www.python.org"
fi